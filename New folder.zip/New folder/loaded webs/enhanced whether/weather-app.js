function showLoading(msg) {
  loadingText.textContent = msg;
}

function clearLoading() {
  loadingText.textContent = '';
}

async function fetchWeather(city) {
  try {
    showLoading('Fetching weather...');
    const res = await fetch(`https://api.weatherapi.com/v1/forecast.json?key=${apiKey}&q=${encodeURIComponent(city)}&days=5&aqi=no&alerts=no`);
    if (!res.ok) throw new Error('City not found or API error');
    const data = await res.json();
    currentCity = data.location.name;
    currentCoords = {lat: data.location.lat, lon: data.location.lon};
    setBackgroundByTime(data.location.localtime);
    displayWeather(data);
    displayForecast(data.forecast.forecastday);
    displayHourly(data.forecast.forecastday[0].hour);
    clearLoading();
    saveFavorite(currentCity);
  } catch (err) {
    clearLoading();
    alert(err.message);
  }
}

async function fetchWeatherByCoords(lat, lon) {
  try {
    showLoading('Fetching weather by location...');
    const res = await fetch(`https://api.weatherapi.com/v1/forecast.json?key=${apiKey}&q=${lat},${lon}&days=5&aqi=no&alerts=no`);
    if (!res.ok) throw new Error('Location not found or API error');
    const data = await res.json();
    currentCity = data.location.name;
    currentCoords = {lat: data.location.lat, lon: data.location.lon};
    cityInput.value = currentCity;
    setBackgroundByTime(data.location.localtime);
    displayWeather(data);
    displayForecast(data.forecast.forecastday);
    displayHourly(data.forecast.forecastday[0].hour);
    clearLoading();
    saveFavorite(currentCity);
  } catch (err) {
    clearLoading();
    alert(err.message);
  }
}

function getLocation() {
  if (!navigator.geolocation) {
    alert('Geolocation not supported');
    return;
  }
  showLoading('Getting your location...');
  navigator.geolocation.getCurrentPosition(
    pos => fetchWeatherByCoords(pos.coords.latitude, pos.coords.longitude),
    err => {
      clearLoading();
      alert('Location access denied or unavailable');
    }
  );
}

function saveFavorite(city) {
  if (!city) return;
  let favs = JSON.parse(localStorage.getItem('favorites') || '[]');
  if (!favs.includes(city)) {
    favs.push(city);
    localStorage.setItem('favorites', JSON.stringify(favs));
    renderFavorites();
  }
}

function renderFavorites() {
  let favs = JSON.parse(localStorage.getItem('favorites') || '[]');
  favoriteList.innerHTML = favs.map(city => `<button class="favorite-city" aria-label="Load weather for ${city}">${city}</button>`).join('');
  favoriteList.querySelectorAll('.favorite-city').forEach(btn => {
    btn.addEventListener('click', () => {
      cityInput.value = btn.textContent;
      fetchWeather(btn.textContent);
    });
  });
}

function toggleUnit(e) {
  currentUnit = e.target.value;
  if (currentCity) fetchWeather(currentCity);
}

document.getElementById('getWeatherBtn').addEventListener('click', () => {
  const city = cityInput.value.trim();
  if (city) fetchWeather(city);
});
document.getElementById('useLocationBtn').addEventListener('click', getLocation);
document.getElementById('refreshBtn').addEventListener('click', () => {
  if (currentCity) fetchWeather(currentCity);
  else alert('Please enter a city first');
});
unitRadios.forEach(radio => radio.addEventListener('change', toggleUnit));

// Enter key triggers Get Weather
cityInput.addEventListener('keydown', e => {
  if (e.key === 'Enter') {
    const city = cityInput.value.trim();
    if (city) fetchWeather(city);
  }
});

// On load, show favorites
renderFavorites();
